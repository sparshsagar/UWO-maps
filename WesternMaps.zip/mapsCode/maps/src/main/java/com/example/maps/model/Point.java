package com.example.maps.model;

public class Point {

    private String buildingName;
    private String floorName;
    private String roomNumber;
    private String name;
    private String type;
    private String additionalInformation;
    double x , y;
    private String hours;
    private String roomCapacity;


    public Point(String buildingName , String floorName , String roomNumber , String name , String type , double x , double y , String additionalInformation) {

        this.buildingName = buildingName;
        this.floorName = floorName;
        this.roomNumber = roomNumber;
        this.name = name;
        this.type = type;
        this.x = x;
        this.y = y;
        this.additionalInformation = additionalInformation;
    }
    public Point() {

    }
    public Point(String buildingName , String floorName , String roomNumber , String type , double x , double y , String additionalInformation) {

        this.buildingName = buildingName;
        this.floorName = floorName;
        this.roomNumber = roomNumber;
        this.name = roomNumber+" | "+ buildingName+" | "+floorName;
        this.type = type;
        this.x = x;
        this.y = y;
        this.additionalInformation = additionalInformation;
    }

    public String getRoomNumber() {
        return this.roomNumber;
    }
    public String getName() {
        return this.name;
    }
    public String getType() {
        return this.type;
    }
    public double getX() {
        return this.x;
    }
    public double getY() {
        return this.y;
    }
    public String getAdditionalInformation() {
        return this.additionalInformation;
    }
    public String getBuildingName() {
        return this.buildingName;
    }
    public String getFloorName() {
        return this.floorName;
    }
    public String getRoomCapacity() {
        return this.roomCapacity;
    }
    public String getHours() {
        return this.hours;
    }



    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }
    public void setName(String name) {
        this.name = name;
    }
    public void setType(String type) {
        this.type = type;
    }
    public void setX(double x) {
        this.x = x;
    }
    public void setY(double y) {
        this.y = y;
    }
    public void setAdditionalInformation(String additionalInformation) {
        this.additionalInformation = additionalInformation;
    }
    public void setBuildingName(String buildingName) {
        this.buildingName = buildingName;
    }
    public void setFloorName(String floorName) {
        this.floorName = floorName;
    }
    public void setRoomCapacity(String roomCapacity) {
        this.roomCapacity = roomCapacity;
    }
    public void setHours(String hours) {
        this.hours = hours;
    }

    @Override
    public String toString() {

        return String.format("Room Number\t: %s\n" +
                "Room Name\t: %s\n" +
                "Hours \t: %s\n" +
                "Capacity \t: %s\n" +
                "Floor \t: %s\n" +
                "Building \t: %s\n" +
                "Type \t: %s\n",roomNumber , name , hours , roomCapacity , floorName , buildingName , type).concat(this.additionalInformation.isEmpty()? "" :
                String.format("Additional Information\t: %s\n",additionalInformation));
    }


}
