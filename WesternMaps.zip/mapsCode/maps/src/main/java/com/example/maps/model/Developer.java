package com.example.maps.model;

import java.util.List;
import java.util.ArrayList;

public class Developer extends User {

    public Developer(String firstName , String lastName , String email , String password) {
        super(firstName , lastName , email , password);
    }

}
