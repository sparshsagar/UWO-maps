package com.example.maps.controller;

import com.example.maps.model.User;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.layout.Pane;
import javafx.scene.control.TextField;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Button;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

import java.net.URL;
import java.util.ResourceBundle;

import org.json.JSONObject;
import org.json.JSONArray;

import java.io.IOException;
import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.BufferedWriter;


public class SignController implements Initializable {

    @FXML
    private TextField firstnameInput , lastnameInput , emailInput , passwordInput;

    @FXML
    private Pane rootContainer;

    @FXML
    private Button signupButton;

    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }

    /**
     * sign up button event handler, get user input , create User based on that input and save it to the json file then show a dialog box with the information 'account was created successfully , you can log in with the credentials you provided '
     * @throws Exception
     */
    @FXML
    private void signup() throws Exception {

        String firstName = firstnameInput.getText();
        String lastName = lastnameInput.getText();
        String email = emailInput.getText();
        String password = User.getDigest(passwordInput.getText());

        User user = new User(firstName , lastName , email , password);

        JSONObject userJson = new JSONObject(user);



        String contentJSONFile = "";
        String line;

        File file = new File("./data") ;
        if(!file.exists() || !file.isDirectory()) {
            file.mkdir();
        }
        File usersFile = new File("./data/users.json");
        if(!usersFile.exists()) {
            usersFile.createNewFile();
        }

        BufferedReader reader = new BufferedReader(new FileReader(usersFile));

        while((line=reader.readLine())!=null)
            contentJSONFile = contentJSONFile.concat(line);

        reader.close();

        JSONArray usersJSONArray = new JSONArray(contentJSONFile.isBlank() ? "[]" : contentJSONFile);

        usersJSONArray.put(userJson);


        FileWriter fw = null;
        BufferedWriter writer = null;

        try {
            fw = new FileWriter(usersFile);
            writer = new BufferedWriter(fw);

            writer.write(usersJSONArray.toString(2));
            fw.flush();
            writer.flush();
        }
        catch(IOException ex) {

        }
        finally {
            if(fw!=null) fw.close();
            if(writer!=null) writer.close();
        }

        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Message");
        alert.setHeaderText("Signup was successfully Done !");
        alert.setContentText("Thank you for your registration, use the email & password you signup with to login!");
        alert.showAndWait();

        Parent loginParent = FXMLLoader.load(this.getClass().getResource("/com/example/maps/login.fxml"));
        this.rootContainer.getScene().setRoot(loginParent);

    }

    @FXML
    private void signupMouseEnter() {
        this.signupButton.setStyle("-fx-background-color: #A5D7E8; -fx-background-radius: 5;");
    }
    @FXML
    private void signupMouseExit() {
        this.signupButton.setStyle("-fx-background-color: #19376D; -fx-background-radius: 5;");
    }
}