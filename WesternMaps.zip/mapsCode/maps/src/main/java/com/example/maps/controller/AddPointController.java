package com.example.maps.controller;

import com.example.maps.model.Developer;
import com.example.maps.model.PointTypes;
import com.example.maps.model.User;
import com.example.maps.model.Point;

import com.example.maps.model.User;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;


import java.net.URL;
import java.util.ResourceBundle;

import java.io.IOException;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.BufferedWriter;

import org.json.JSONObject;
import org.json.JSONArray;


public class AddPointController implements Initializable {

    @FXML
    private TextField roomNumberInput , nameInput  , roomCapacityInput , hoursInput ;

    @FXML
    private TextArea infoInput;

    @FXML
    private ComboBox<String> typeInput;

    @FXML
    private Pane rootElement;


    public static Initializable mainViewController;

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        this.fillTypes();
    }

    /**
     * get user input and create a point based on that input, save it to json file and call createPoint() function from Controller to make it viewable in the map view
     * @throws Exception
     */
    @FXML
    private void save() throws Exception {

        String buildingName = Controller.addPointBuildingName;
        String floorName = Controller.addPointFloorName;
        String roomNumber = this.roomNumberInput.getText();
        String type = this.typeInput.getSelectionModel().getSelectedItem();
        String additionalInformation = this.infoInput.getText();
        double x = Controller.globalX , y = Controller.globalY;
        String roomCapacity = roomCapacityInput.getText();
        String hours = hoursInput.getText();

        Point p = new Point(buildingName , floorName , roomNumber , type , x , y , additionalInformation);
        p.setRoomCapacity(roomCapacity);
        p.setHours(hours);

        User.currentLoggedUser.getPoints().add(p);

        BufferedReader reader ;
        String line , content="";
        if(User.currentLoggedUser instanceof Developer) {
            reader = new BufferedReader(new FileReader("./data/developers.json"));
        }
        else {
            reader = new BufferedReader(new FileReader("./data/users.json"));
        }

        while((line=reader.readLine())!=null) {
            content = content.concat(line);
        }
        reader.close();
        JSONArray jsonArray = new JSONArray(content);
        jsonArray.put(LoginController.jsonObjectIndex , new JSONObject(User.currentLoggedUser));

        FileWriter fw = null;
        BufferedWriter writer = null;

        try {
            if(User.currentLoggedUser instanceof Developer) {
                fw = new FileWriter("./data/developers.json");
            }
            else {
                fw = new FileWriter("./data/users.json");
            }
            writer = new BufferedWriter(fw);
            writer.write(jsonArray.toString(2));
            fw.flush();
            writer.flush();
        }
        catch(IOException ex) {

        }
        finally {
            if(fw!=null) fw.close();
            if(writer!=null) writer.close();
        }

        this.cancel();

        ((Controller)mainViewController).createDraggablePoint(p);
        ((Controller)mainViewController).addCreatedPointToList(p);

    }

    /**
     * cancel button event handler, just close the add point stage
     */
    @FXML
    private void cancel() {

        ((Stage)this.rootElement.getScene().getWindow()).close();
        Controller.addPointButtonGlobal.setDisable(false);
    }

    /**
     * fill the types list view with data loaded from fields of enum com.model.PointTypes
     */
    private void fillTypes() {

        if(User.currentLoggedUser instanceof Developer) {

            for(PointTypes type : PointTypes.values()) {
                this.typeInput.getItems().add(type.name());
            }
            this.typeInput.getSelectionModel().selectFirst();
            return;
        }

        this.typeInput.getItems().add(PointTypes.Custom.name());
        this.typeInput.getSelectionModel().selectFirst();
        this.typeInput.setDisable(true);

        this.typeInput.getSelectionModel().selectedItemProperty().addListener((ObservableValue<? extends String> obv , String oldValue , String newValue) -> {
            if(newValue==null) {
                this.typeInput.getSelectionModel().select(oldValue);
            }
        });

    }
}