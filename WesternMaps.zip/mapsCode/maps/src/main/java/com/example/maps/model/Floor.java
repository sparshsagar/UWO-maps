package com.example.maps.model;

import java.util.Map;
import java.util.HashMap;


import javafx.scene.control.Button;


public class Floor {

    public static final Map<Button , Floor> buttonFloorMap = new HashMap<>();

    private String name;
    private String imagePath ;

    public Floor(String name , String imagePath) {
        this.name = name;
        this.imagePath = imagePath;
    }
    public Floor() {

    }

    public void setName(String name) {
        this.name = name;
    }
    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    public String getName() {
        return this.name;
    }
    public String getImagePath() {
        return this.imagePath;
    }

}
