package com.example.maps.api;

import javafx.application.Platform;
import javafx.scene.control.Label;

import java.util.TimerTask;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.BufferedReader;

import java.net.URL;
import java.net.URI;

import org.json.JSONObject;

import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;


public class Weather extends TimerTask {

    private Label status=null;

    public static Weather instance=null;

    private Weather() {

    }

    public static Weather getInstance() {

        return instance==null ? instance = new Weather() : instance;
    }

    @Override
    public void run() {

        try {
            String ipAddress = getIpAddress();

            JSONObject apiResponse = getResponse(ipAddress);

            String location = getLocation(apiResponse);
            double temp = getTemperature(apiResponse);

            String labelContent = String.format("%s\t\t  %d°",location, (int)Math.ceil(temp));

            Platform.runLater(() -> {
                this.status.setText(labelContent);
            });

        }
        catch(Exception ex) {

            Platform.runLater(() -> {
                this.status.setText("Weather Service is not available currently !");
            });
        }
    }

    private String getIpAddress() throws IOException {

        BufferedReader reader = new BufferedReader(new InputStreamReader(new URL("http://checkip.amazonaws.com").openStream()));

        return reader.readLine();
    }

    private JSONObject getResponse(String address) throws Exception {

        String endPoint = String.format("http://api.weatherapi.com/v1/current.json?key=%s&q=%s" , "1ffdbce9649b49b9942230425230604" , address);

        HttpRequest request = HttpRequest.newBuilder(new URI(endPoint)).GET().build();

        HttpClient client = HttpClient.newHttpClient();

        HttpResponse<String> response = client.send(request , BodyHandlers.ofString());

        String body = response.body();

        return new JSONObject(body);
    }

    private String getLocation(JSONObject obj) throws Exception {

        return obj.getJSONObject("location").getString("name");
    }

    private double getTemperature(JSONObject obj) throws Exception {

        return obj.getJSONObject("current").getDouble("temp_c");
    }

    public void setStatus(Label status) {
        this.status = status;
    }
    public Label getStatus() {
        return this.status;
    }
}