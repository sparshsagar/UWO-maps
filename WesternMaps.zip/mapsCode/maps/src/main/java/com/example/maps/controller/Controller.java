package com.example.maps.controller;

import com.example.maps.Main;
import com.example.maps.api.Weather;
import com.example.maps.model.PointTypes;
import com.example.maps.model.Building;
import com.example.maps.model.Floor;
import com.example.maps.model.Point;
import com.example.maps.model.User;
import com.example.maps.model.Developer;

import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.input.InputEvent;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.VBox;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.scene.paint.Color;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;


import java.io.*;
import java.net.URL;
import java.util.*;

import javafx.scene.text.FontWeight;
import javafx.stage.StageStyle;
import org.json.JSONObject;
import org.json.JSONArray;


import java.util.Map;
import java.util.HashMap;


public class Controller implements Initializable {


    public static final Timer timer = new Timer();
    @FXML
    private VBox rootElement , floorsButtonContainer;

    @FXML
    private Pane mapViewInnerContainer;

    @FXML
    private ScrollPane mapViewContainer;

    private Button selectedBuilding , selectedFloor ;

    @FXML
    private ListView pointsTypes , favPoints , pointsList;

    @FXML
    private Button middlesexButton , alumniHallButton , labattHealthButton , addPointButton;

    @FXML
    private TextField searchPointText;

    @FXML
    private ListView currentFloorPointsList;

    @FXML
    private Label weatherStatus;

    private Map<String , String> typeColorMap = new HashMap<>();

    private Map<String , Point> namePointMap = new HashMap<>();

    private Map<String , Button> buildingNameButtonMap = new HashMap<>();

    private Map<String , Button> floorNameButtonMap = new HashMap<>();

    private List<Label> allPointsLabels = new ArrayList<>();

    private double startX , startY; //these fields will be used to make points draggable (detect the coordinate of a point the moment we clicked on it)


    public static Button addPointButtonGlobal;
    public static String addPointBuildingName , addPointFloorName;
    public static double globalX , globalY;

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        System.out.println(User.currentLoggedUser instanceof Developer ? "Logged in as Developer" : "Logged in as Normal User");

        String[] arr = {"ORANGE" , "RED" , "CYAN" , "GREEN" , "YELLOW" , "PURPLE" , "PINK" , "BROWN" , "NAVY" , "LIME"};
        for(int i=0; i<arr.length; i++) {
            typeColorMap.put(PointTypes.values()[i].name() , arr[i]);
        }
        this.fillPointsTypes();
        this.buildingNameButtonMap.put(this.alumniHallButton.getText() , alumniHallButton);
        this.buildingNameButtonMap.put(this.middlesexButton.getText() , middlesexButton);
        this.buildingNameButtonMap.put(this.labattHealthButton.getText() , labattHealthButton);
        favPoints.setPlaceholder(new Label("No favourite points were added"));
        pointsList.setPlaceholder(new Label("No Point of Interest was added yet!"));
        this.alumniHallButton.setStyle("-fx-background-color : #A5D7E8; -fx-background-radius : 5;");

        this.selectedBuilding = this.alumniHallButton;
        try {
            this.getBuildingsFromJSONFile();
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        this.createButtons(Building.buttonBuildingMap.get(this.alumniHallButton).getFloors());

        addPointButtonGlobal = addPointButton;

        AddPointController.mainViewController = this;


        Main.applicationWindow.getScene().getWindow().setOnCloseRequest((event) -> {

            try {
                //updating the json file when user/dev close the application
                BufferedReader reader = new BufferedReader(new FileReader(User.currentLoggedUser instanceof Developer ? "./data/developers.json" : "./data/users.json"));
                String line , content="";

                while((line=reader.readLine())!=null)
                    content = content.concat(line);
                reader.close();
                JSONArray array = new JSONArray(content);

                array.put(LoginController.jsonObjectIndex , new JSONObject(User.currentLoggedUser));

                FileWriter fw = null;
                BufferedWriter writer = null;
                try {
                    fw = new FileWriter(User.currentLoggedUser instanceof Developer ? "./data/developers.json" : "./data/users.json");
                    writer = new BufferedWriter(fw);

                    writer.write(array.toString(2));
                    writer.flush();
                    fw.flush();
                }catch(IOException ex) {
                    throw ex;
                }
                finally {
                    if(fw!=null) fw.close();
                    if(writer!=null) writer.close();
                }

            }
            catch(Exception e) {
                e.printStackTrace();
            }
        });

        loadAllPoints();

        initWeather();
    }

    private void initWeather() {

        Weather task = Weather.getInstance();

        if(task.getStatus()==null) {
            //if it was null, i.e this is the first instnace of weather that was created during runtime, so calling the function schedule() from Timer class won't throw any error !
            task.setStatus(weatherStatus);
            timer.schedule(task , 0 , 20000);
        }
        else {
            weatherStatus.setText(task.getStatus().getText());
            task.setStatus(weatherStatus);
        }
    }

    /**
     * Load points in the current logged-in user points list and add them to the list view that contains all the points of interest and also make those points viewable in the map
     */
    private void loadAllPoints() {
        List<Point> userPoints = User.currentLoggedUser.getPoints();

        for(int i=0; i<userPoints.size(); i++) {

            Point currentPoint = userPoints.get(i);
            Label currentPointLabel = new Label(currentPoint.getName());
            pointsList.getItems().add(currentPointLabel);
            this.allPointsLabels.add(currentPointLabel);
            this.namePointMap.put(currentPoint.getName() , currentPoint);
            currentPointLabel.setOnMouseClicked((MouseEvent event) -> {
                if(event.getButton().equals(MouseButton.PRIMARY)) {
                    if(event.getClickCount()==2) {
                        String buildingName = this.namePointMap.get(currentPointLabel.getText()).getBuildingName();
                        String floorName = this.namePointMap.get(currentPointLabel.getText()).getFloorName();
                        this.buildingNameButtonMap.get(buildingName).fire();
                        this.floorNameButtonMap.get(floorName).fire();
                        this.mapViewContainer.setHvalue(currentPoint.getX()/mapViewInnerContainer.getPrefWidth());
                        this.mapViewContainer.setVvalue(currentPoint.getY()/mapViewInnerContainer.getPrefHeight());

                    }
                }
            });
            if(currentPoint.getFloorName()==this.selectedFloor.getText() && currentPoint.getBuildingName().equals(this.selectedBuilding.getText())) {
                createDraggablePoint(currentPoint);

            }
        }

        if(User.currentLoggedUser instanceof Developer) return;

        List<Point> developerPoints = LoginController.developersPoints;

        for(int i=0; i<developerPoints.size(); i++) {
            Point currentPoint = developerPoints.get(i);
            Label currentPointLabel = new Label(currentPoint.getName());
            this.namePointMap.put(currentPoint.getName() , currentPoint);
            pointsList.getItems().add(currentPointLabel);
            this.allPointsLabels.add(currentPointLabel);
            currentPointLabel.setOnMouseClicked((MouseEvent event) -> {
                if(event.getButton().equals(MouseButton.PRIMARY)) {
                    if(event.getClickCount()==2) {
                        String buildingName = this.namePointMap.get(currentPointLabel.getText()).getBuildingName();
                        String floorName = this.namePointMap.get(currentPointLabel.getText()).getFloorName();
                        this.buildingNameButtonMap.get(buildingName).fire();
                        this.floorNameButtonMap.get(floorName).fire();
                        this.mapViewContainer.setHvalue(currentPoint.getX()/mapViewInnerContainer.getPrefWidth());
                        this.mapViewContainer.setVvalue(currentPoint.getY()/mapViewInnerContainer.getPrefHeight());

                    }
                }
            });
            if(currentPoint.getFloorName()==this.selectedFloor.getText() && currentPoint.getBuildingName().equals(this.selectedBuilding.getText())) {
                createPoint(currentPoint);

            }
        }


    }

    /**
     * fill list view of point types for the enum PointTypes
     */
    private void fillPointsTypes() {

        for(PointTypes type : PointTypes.values()) {

            CheckBox item = new CheckBox(type.name());
            pointsTypes.getItems().add(item);
            item.setOnAction((event) -> {
                for(Node node : floorsButtonContainer.getChildren()) {
                    if(!((Button)node).equals(this.selectedFloor)) {
                        Button oldSelected = this.selectedFloor;
                        ((Button)node).fire();
                        oldSelected.fire();
                        break;
                    }
                }
            });

        }

    }

    /**
     *
     * event handler for the search bar, whenever user typed something in it, the list view of all points will be updated based on the text written in this search bar
     *
     * @param event
     */
    @FXML
    private void searchPointTyped(KeyEvent event) {

        String inputSearchText = this.searchPointText.getText().toLowerCase().trim();


        if(inputSearchText.isEmpty()) {
            this.pointsList.getItems().clear();
            this.pointsList.getItems().addAll(this.allPointsLabels);
            return;
        }

        this.pointsList.getItems().clear();

        for(int i=0; i<this.allPointsLabels.size(); i++) {

            String currentPointName = allPointsLabels.get(i).getText().toLowerCase().trim();

            if(currentPointName.contains(inputSearchText)) {
                this.pointsList.getItems().add(allPointsLabels.get(i));
            }
        }

    }

    @FXML
    private void middlesexMouseEnter() {
        this.updateButtonMouseEnter(middlesexButton);
    }
    @FXML
    private void middlesexMouseExit() {
        this.updateButtonMouseExit(middlesexButton);
    }
    @FXML
    private void alumniMouseEnter() {
        this.updateButtonMouseEnter(alumniHallButton);
    }
    @FXML
    private void alumniMouseExit() {
        this.updateButtonMouseExit(alumniHallButton);
    }
    @FXML
    private void labattMouseEnter() {
        this.updateButtonMouseEnter(labattHealthButton);
    }
    @FXML
    private void labattMouseExit() {
        this.updateButtonMouseExit(labattHealthButton);
    }

    @FXML
    private void labattAction() {
        this.selectedBuilding(labattHealthButton);
    }
    @FXML
    private void alumniAction() {
        this.selectedBuilding(alumniHallButton);
    }
    @FXML
    private void middlesexAction() {
        this.selectedBuilding(middlesexButton);
    }

    /**
     *
     * logout button event handler, take the user out of the map view and bring bach the login view
     *
     * @throws Exception
     */
    @FXML
    private void logout() throws Exception {

        Parent loginParent = FXMLLoader.load(this.getClass().getResource("/com/example/maps/login.fxml"));
        this.rootElement.getScene().setRoot(loginParent);
        ((Stage)loginParent.getScene().getWindow()).setWidth(600);
        ((Stage)loginParent.getScene().getWindow()).setMinWidth(600);
        ((Stage)loginParent.getScene().getWindow()).setHeight(400);
        ((Stage)loginParent.getScene().getWindow()).setMinHeight(400);
        loginParent.getScene().getWindow().centerOnScreen();

        //save all the changes
        try {
            //updating the json file when user/dev close the application
            BufferedReader reader = new BufferedReader(new FileReader(User.currentLoggedUser instanceof Developer ? "./data/developers.json" : "./data/users.json"));
            String line , content="";

            while((line=reader.readLine())!=null)
                content = content.concat(line);
            reader.close();
            JSONArray array = new JSONArray(content);

            array.put(LoginController.jsonObjectIndex , new JSONObject(User.currentLoggedUser));

            FileWriter fw = null;
            BufferedWriter writer = null;
            try {
                fw = new FileWriter(User.currentLoggedUser instanceof Developer ? "./data/developers.json" : "./data/users.json");
                writer = new BufferedWriter(fw);

                writer.write(array.toString(2));
                writer.flush();
                fw.flush();
            }catch(IOException ex) {
                throw ex;
            }
            finally {
                if(fw!=null) fw.close();
                if(writer!=null) writer.close();
            }

        }
        catch(Exception e) {
            e.printStackTrace();
        }

        //clear the already loaded list (developerPoints
        LoginController.developersPoints.clear();
    }

    /**
     *
     * add point button event handler, show a stage with some input fields that user will give data for the new created point
     *
     * @throws Exception
     */
    @FXML
    private void addPoint() throws Exception {

        Stage addPointStage = new Stage(StageStyle.UTILITY);
        addPointStage.setTitle("Add Point");
        String buildingName = this.selectedBuilding.getText();
        Map<String , Button> floorNameFloorButtonMap = new HashMap<>();
        Label buildingLabel = new Label("Building : "+buildingName);
        buildingLabel.setStyle("-fx-font-size : x-large; -fx-font-weight : bold;");
        buildingLabel.setPrefWidth(400);
        buildingLabel.setAlignment(Pos.CENTER);
        buildingLabel.setTranslateY(75);
        ComboBox<String> floorsComboBox = new ComboBox();
        for(int i=0; i<this.floorsButtonContainer.getChildren().size(); i++) {
            Button currentButton = (Button)this.floorsButtonContainer.getChildren().get(i);
            floorsComboBox.getItems().add(currentButton.getText());
            floorNameFloorButtonMap.put(currentButton.getText() , currentButton);
        }

        floorsComboBox.setPrefWidth(250);
        floorsComboBox.setStyle("-fx-font-size : 13; -fx-font-weight : bold;");
        floorsComboBox.setTranslateX(75);
        floorsComboBox.setTranslateY(175);
        floorsComboBox.getSelectionModel().selectFirst();
        floorsComboBox.getSelectionModel().selectedItemProperty().addListener((ObservableValue<? extends String> obv , String oldV , String newV) -> {
            if(oldV.equals(newV) || newV==null) {
                return;
            }
            floorNameFloorButtonMap.get(newV).fire();
        });

        Button nextButton = new Button("Next");
        nextButton.setStyle("-fx-font-size : 13; -fx-font-weight : bold; -fx-font-family : sans serif;");
        nextButton.setPrefSize(100 , 30);
        nextButton.setTranslateX(150);
        nextButton.setTranslateY(300);
        nextButton.setCursor(Cursor.HAND);

        Pane addFirstContainer = new Pane();
        addFirstContainer.setPrefSize(400 , 400);
        addFirstContainer.getChildren().addAll(buildingLabel , floorsComboBox , nextButton);

        Scene addFirstScene = new Scene(addFirstContainer );
        addPointStage.setScene(addFirstScene);
        addPointStage.setResizable(false);
        addPointStage.setWidth(400); addPointStage.setHeight(400);
        addPointStage.show();
        addPointStage.setAlwaysOnTop(true);
        this.addPointButton.setDisable(true);

        addPointStage.setOnCloseRequest((event) -> {
            this.addPointButton.setDisable(false);
        });

        nextButton.setOnAction((event) -> {
            try {
                if(floorsComboBox.getSelectionModel().getSelectedItem()==null) {
                    return;
                }
                Parent addPointParent = FXMLLoader.load(Objects.requireNonNull(this.getClass().getResource("/com/example/maps/addPointView.fxml")));
                Controller.addPointBuildingName = this.selectedBuilding.getText();
                Controller.addPointFloorName = floorsComboBox.getSelectionModel().getSelectedItem();
                addPointStage.getScene().setRoot(addPointParent);
                addPointStage.setWidth(400); addPointStage.setHeight(500);
                addPointStage.centerOnScreen();

                globalX = (((ImageView)this.mapViewInnerContainer.getChildren().get(0)).getFitWidth() + 40)/2; //we will center the point as we will be displaying it as an empty pane with the width 40
                globalY = (((ImageView)this.mapViewInnerContainer.getChildren().get(0)).getFitHeight() + 20)/2; //we will center the point as we will be displaying it as an empty pane with the height 20



            } catch (Exception e) {
                e.printStackTrace();
            }
        });

    }

    /**
     * show a dialog box that contains information about the application (creators, release date , version..)
     */
    @FXML
    private void about() {

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("About");
        String headerText="Application Name : Western Maps\n" +
                "Application Version : 3.0.0\n" +
                "Release Date : 5th april 2023";

        String contentText = "Project Team Members (Contact email)\n\n" +
                "Karim Khalil (kkhalil@uwo.ca)\n" +
                "Alexander Boulos (aboulos4@uwo.ca)\n" +
                "Sparsh Sagar (ssagar26@uwo.ca)\n" +
                "Ganesh Krishna Menon (gmenon3@uwo.ca)\n" +
                "Siddhant Saraf (ssaraf@uwo.ca)";

        alert.setHeaderText(headerText);
        alert.setContentText(contentText);

        alert.show();

    }

    /**
     * show a window that contains user guide information that will help users understand of the application works
     * @throws Exception
     */
    @FXML
    private void userGuide() throws Exception {

        Stage stage = new Stage(StageStyle.UTILITY);
        Parent parent = FXMLLoader.load(this.getClass().getResource("/com/example/maps/userGuide.fxml"));
        Scene scene = new Scene(parent , 600 , 400);
        stage.setScene(scene);
        stage.sizeToScene();
        stage.show();
        stage.setAlwaysOnTop(true);
        stage.setTitle("User Guide");
    }


    private void updateButtonMouseEnter(Button button) {
        if(this.selectedBuilding.equals(button)) return;
        button.setStyle("-fx-background-color : #A5D7E8; -fx-background-radius : 5;");
    }
    private void updateButtonMouseExit(Button button) {
        if(this.selectedBuilding.equals(button)) return;
        button.setStyle("-fx-background-color : #19376D; -fx-background-radius : 5;");
    }

    /**
     *
     * @param targetBuilding Button that user clicked to switch from the current to it
     */
    private void selectedBuilding(Button targetBuilding) {
        if(this.selectedBuilding.equals(targetBuilding)) {
            return;
        }

        //update views of the target button
        updateButtonMouseEnter(targetBuilding);

        Button tmp = this.selectedBuilding;
        this.selectedBuilding = targetBuilding;

        updateButtonMouseExit(tmp);


        List<Floor> floors = Building.buttonBuildingMap.get(selectedBuilding).getFloors();

        createButtons(floors);


    }

    /**
     * Load Buildings from the JSON file that exists in the resources of the application
     * @throws Exception
     */
    private void getBuildingsFromJSONFile() throws Exception {

        BufferedReader reader = new BufferedReader(new InputStreamReader(this.getClass().getResourceAsStream("/com/example/maps/mapsData.json")));
        String line;
        String content = "";

        while((line=reader.readLine())!=null) {
            content = content.concat(line);
        }

        this.getBuildingsFromJSONArray(new JSONArray(content));
    }

    /**
     *
     * @param array json array loaded from buildings.json file
     * @throws Exception
     */
    private void getBuildingsFromJSONArray(JSONArray array) throws Exception {

        JSONObject alumniJSONObject = array.getJSONObject(0);
        JSONObject labattJSONObject = array.getJSONObject(1);
        JSONObject middlesexJSONObject = array.getJSONObject(2);

        Building alumniObject = getBuildingFromJSONObject(alumniJSONObject);
        Building labattObject = getBuildingFromJSONObject(labattJSONObject);
        Building middlesexObject = getBuildingFromJSONObject(middlesexJSONObject);

        associateBuildingWithButton(alumniObject , this.alumniHallButton);
        associateBuildingWithButton(labattObject , this.labattHealthButton);
        associateBuildingWithButton(middlesexObject , this.middlesexButton);

    }

    /**
     * create instance of building using a json object that has the same keys as Building class fields
     * @param jsonObject json object that will use to create building instance
     * @return instance of Building that we created using the data from json object
     * @throws Exception
     */
    private Building getBuildingFromJSONObject(JSONObject jsonObject) throws Exception {

        String name = jsonObject.getString("name");
        String imagesDirectory = jsonObject.getString("imagesDirectory");
        JSONArray floorsJSONArray = jsonObject.getJSONArray("floors");
        List<Floor> floors = getFloorsFromJSONArray(floorsJSONArray , imagesDirectory);
        Building result = new Building(name , floors);

        return result;
    }

    /**
     * create a list of floor using json array
     * @param array given json array of floors
     * @param imagesDirectory directory that contains this floor images
     * @return List of floors
     * @throws Exception
     */
    private List<Floor> getFloorsFromJSONArray(JSONArray array , String imagesDirectory) throws Exception {

        List<Floor> result = new ArrayList<>();
        for(int i=0; i<array.length(); i++) {
            JSONObject current = array.getJSONObject(i);
            String name = current.getString("name");
            String imagePath = imagesDirectory.concat(current.getString("image"));
            result.add(new Floor(name , imagePath));
        }

        return result;
    }

    /**
     *
     * @param building
     * @param button button that takes user to the given building
     * @throws Exception
     */
    private void associateBuildingWithButton(Building building , Button button) throws Exception {

        Building.buttonBuildingMap.put(button , building);
    }

    /**
     * clear the floors buttons container and create new ones from floors list and add them to floors button container
     * @param floors
     */
    private void createButtons(List<Floor> floors) {

        this.floorsButtonContainer.getChildren().clear();

        for(int i=0; i<floors.size(); i++) {
            addFloorButton(floors.get(i));
        }
        this.floorsButtonContainer.getChildren().get(0).setStyle("-fx-background-color :  #A5D7E8; -fx-background-radius : 5;");
        this.selectedFloor = new Button();
        ((Button)floorsButtonContainer.getChildren().get(0)).fire();



    }

    /**
     * add a button to the floors buttons Container
     * @param floor
     */
    private void addFloorButton(Floor floor) {



        Button button = new Button(floor.getName());
        button.setFont(Font.font("SansSerif" , FontWeight.BOLD , 15));
        button.setTextFill(Color.valueOf("#fff"));
        button.setStyle("-fx-background-color :  #19376D; -fx-background-radius : 5;");
        button.setMaxWidth(Double.MAX_VALUE);
        button.setPrefHeight(30);
        button.setCursor(Cursor.HAND);

        button.setOnAction((event) -> {
            this.selectFloorButton(button);
        });
        button.setOnMouseEntered((event) -> {
            this.mouseInFloorButton(button);
        });
        button.setOnMouseExited((event) -> {
            this.mouseOutFloorButton(button);
        });

        this.floorsButtonContainer.getChildren().add(button);
        this.floorNameButtonMap.put(button.getText() , button);
        Floor.buttonFloorMap.put(button , floor);
    }

    /**
     * event handler for floors button, it takes the user to another map based on what he clicked (target button)
     * @param target
     */
    private void selectFloorButton(Button target) {
        if(this.selectedFloor.equals(target)) {
            return;
        }

        //update view of target & selectedFloor buttons
        target.setStyle("-fx-background-color : #A5D7E8; -fx-background-radius : 5;");
        this.selectedFloor.setStyle("-fx-background-color : #19376D; -fx-background-radius : 5;");

        //assign target to selectedFloor
        selectedFloor = target;


        //update the mapview
        Floor currentFloor = Floor.buttonFloorMap.get(selectedFloor);

        Image mapImage = new Image(this.getClass().getResourceAsStream(currentFloor.getImagePath()));
        ImageView mapView = new ImageView(mapImage);
        mapViewInnerContainer.setPrefSize(mapImage.getWidth() , mapImage.getHeight());
        mapView.setFitWidth(mapImage.getWidth());
        mapView.setFitHeight(mapImage.getHeight());
        mapViewInnerContainer.getChildren().clear();
        currentFloorPointsList.getItems().clear();
        mapViewInnerContainer.getChildren().add(mapView);
        this.currentFloorPointsList.getItems().clear();
        //now we fill the view with POIs
        List<Point> userPoints = User.currentLoggedUser.getPoints();

        for(int i=0; i<userPoints.size(); i++) {
            if(userPoints.get(i).getFloorName().equals(currentFloor.getName()) && userPoints.get(i).getBuildingName().equals(this.selectedBuilding.getText())) {

                createDraggablePoint(userPoints.get(i));

            }
        }

        if(User.currentLoggedUser instanceof Developer) {
            return;
        }

        List<Point> developerPoints = LoginController.developersPoints;

        for(int i=0; i<developerPoints.size(); i++) {
            if(developerPoints.get(i).getFloorName().equals(currentFloor.getName()) && developerPoints.get(i).getBuildingName().equals(this.selectedBuilding.getText())) {

                createPoint(developerPoints.get(i));


            }
        }

    }
    private void mouseInFloorButton(Button target) {

        if(this.selectedFloor.equals(target)) {
            return;
        }
        target.setStyle("-fx-background-color : #A5D7E8; -fx-background-radius : 5;");
    }
    private void mouseOutFloorButton(Button target) {

        if(this.selectedFloor.equals(target)) {
            return;
        }
        target.setStyle("-fx-background-color : #19376D; -fx-background-radius : 5;");
    }

    /**
     * create point in the map and make it draggable for the current logged-in user
     * @param point
     */
    public void createDraggablePoint(Point point) {

        this.currentFloorPointsList.getItems().add(point.getName());

        //checking for selected filters(classroom,washroom,navigation...)
        ObservableList<CheckBox> items = this.pointsTypes.getItems();
        List<String> selectedTypes = new ArrayList<>();

        for(int i=0 ; i<items.size(); i++) {
            if(items.get(i).isSelected()) selectedTypes.add(items.get(i).getText());
        }
        if(selectedTypes.size()!=0) {
            if(!selectedTypes.contains(point.getType())) return;
        }


        Pane p = new Pane();
        p.setPrefSize(40 , 20);
        p.setTranslateX(point.getX());
        p.setTranslateY(point.getY());
        p.setStyle("-fx-background-color : "+typeColorMap.get(point.getType()).toString()+";");
        this.mapViewInnerContainer.getChildren().add(p);

        p.setOnMousePressed((event) -> {
            startX = event.getX() - p.getTranslateX();
            startY = event.getY() - p.getTranslateY();

        });
        p.setOnMouseDragged((event) -> {

            p.setTranslateX(event.getX() - startX);
            p.setTranslateY(event.getY() - startY);
            point.setX(p.getTranslateX());
            point.setY(p.getTranslateY());

        });

        this.mapViewContainer.setVvalue(p.getTranslateY()/mapViewInnerContainer.getPrefHeight());
        this.mapViewContainer.setHvalue(p.getTranslateX()/mapViewInnerContainer.getPrefWidth());

        p.setOnMouseClicked((MouseEvent event) -> {

            if(event.getButton().equals(MouseButton.PRIMARY)) {
                if(event.getClickCount()==2) {

                    Stage stage = new Stage(StageStyle.UTILITY);
                    Group previewGroup = new Group();
                    Label previewLabel = new Label(point.toString());
                    previewLabel.setPrefSize(400 , 300);
                    previewLabel.setAlignment(Pos.CENTER);
                    Button favorite = new Button(favPoints.getItems().contains(point.getName()) ? "Unfavorite" : "Favorite");
                    favorite.setPrefWidth(100);
                    favorite.setTranslateX(240);
                    favorite.setTranslateY(260);
                    Button delete = new Button("Remove");
                    delete.setPrefWidth(100);
                    delete.setTranslateX(60);
                    delete.setTranslateY(260);
                    previewGroup.getChildren().addAll(previewLabel , favorite , delete);
                    stage.setScene(new Scene(previewGroup , 400 , 300));
                    stage.sizeToScene();
                    stage.setAlwaysOnTop(true);
                    stage.show();

                    favorite.setOnAction((innerEvent) -> {
                        if(favorite.getText().equals("Unfavorite")) {
                            favorite.setText("Favorite");
                            favPoints.getItems().remove(point.getName());

                        }
                        else {
                            favorite.setText("Unfavorite");
                            favPoints.getItems().add(point.getName());
                        }
                    });

                    delete.setOnAction((innerEvent) -> {

                        deletePoint(point);
                        this.mapViewInnerContainer.getChildren().remove(p);
                        stage.close();
                    });

                }
            }
        });
    }

    /**
     * create point in the map but the user won't be able to drag it to another location (these are the points by developer in case current logged-in user a normal user)
     * @param point
     */
    public void createPoint(Point point) {

        this.currentFloorPointsList.getItems().add(point.getName());

        //checking for selected filters(classroom,washroom,navigation...)
        ObservableList<CheckBox> items = this.pointsTypes.getItems();
        List<String> selectedTypes = new ArrayList<>();
        int selectedCounter=0;
        for(int i=0 ; i<items.size(); i++) {
            if(items.get(i).isSelected()) selectedTypes.add(items.get(i).getText());
        }
        if(selectedTypes.size()!=0) {
            if(!selectedTypes.contains(point.getType())) return;
        }

        Pane p = new Pane();
        p.setPrefSize(40 , 20);
        p.setTranslateX(point.getX());
        p.setTranslateY(point.getY());
        p.setStyle("-fx-background-color : "+this.typeColorMap.get(point.getType())+";");

        this.mapViewInnerContainer.getChildren().add(p);


        this.mapViewContainer.setVvalue(p.getTranslateY()/mapViewInnerContainer.getPrefHeight());
        this.mapViewContainer.setHvalue(p.getTranslateX()/mapViewInnerContainer.getPrefWidth());

        p.setOnMouseClicked((MouseEvent event) -> {

            if(event.getButton().equals(MouseButton.PRIMARY)) {
                if(event.getClickCount()==2) {

                    Stage stage = new Stage(StageStyle.UTILITY);
                    Group previewGroup = new Group();
                    Label previewLabel = new Label(point.toString());
                    previewLabel.setPrefSize(400 , 300);
                    previewLabel.setAlignment(Pos.CENTER);
                    previewLabel.setLineSpacing(2);
                    Button favorite = new Button(favPoints.getItems().contains(point.getName()) ? "Unfavorite" : "Favorite");
                    favorite.setPrefWidth(100);
                    favorite.setTranslateX(240);
                    favorite.setTranslateY(260);
                    Button delete = new Button("Remove");
                    delete.setPrefWidth(100);
                    delete.setTranslateX(60);
                    delete.setTranslateY(260);
                    delete.setDisable(true);
                    previewGroup.getChildren().addAll(previewLabel , favorite , delete);
                    stage.setScene(new Scene(previewGroup , 400 , 300));
                    stage.sizeToScene();
                    stage.setAlwaysOnTop(true);
                    stage.show();

                    favorite.setOnAction((innerEvent) -> {
                        if(favorite.getText().equals("Unfavorite")) {
                            favorite.setText("Favorite");
                            favPoints.getItems().remove(point.getName());
                        }
                        else {
                            favorite.setText("Unfavorite");
                            favPoints.getItems().add(point.getName());
                        }
                    });

                }
            }
        });


    }

    /**
     * we call this function in case user desired to delete a point
     * @param point
     */
    private void deletePoint(Point point) {

        //fav list
        favPoints.getItems().remove(point.getName());

        //pointsList
        for(int i=0; i<pointsList.getItems().size(); i++) {
            Label currentLabelPoint = (Label)pointsList.getItems().get(i);
            if(currentLabelPoint.getText().equals(point.getName())) {
                pointsList.getItems().remove(i);
                break;
            }
        }

        //all points Label
        for(int i=0; i<allPointsLabels.size(); i++) {
            Label currentLabelPoint = allPointsLabels.get(i);
            if(currentLabelPoint.getText().equals(point.getName())) {
                allPointsLabels.remove(i);
                break;
            }
        }

        //User points list
        User.currentLoggedUser.getPoints().remove(point);

        //name point map
        this.namePointMap.remove(point.getName());

        //current floor points
        this.currentFloorPointsList.getItems().remove(point.getName());

    }

    /**
     * when the user creates a new point we should add it to the list views in left side of the window
     * @param p
     */
    public void addCreatedPointToList(Point p) {

        String name = p.getName();
        Label pointLabel = new Label(name);
        namePointMap.put(name , p);

        this.pointsList.getItems().add(pointLabel);
        this.allPointsLabels.add(pointLabel);
        this.namePointMap.put(pointLabel.getText() , p);

        pointLabel.setOnMouseClicked((MouseEvent event) -> {
            if(event.getButton().equals(MouseButton.PRIMARY)) {
                if(event.getClickCount()==2) {
                    String buildingName = this.namePointMap.get(pointLabel.getText()).getBuildingName();
                    String floorName = this.namePointMap.get(pointLabel.getText()).getFloorName();
                    this.buildingNameButtonMap.get(buildingName).fire();
                    this.floorNameButtonMap.get(floorName).fire();
                    this.mapViewContainer.setHvalue(p.getX()/mapViewInnerContainer.getPrefWidth());
                    this.mapViewContainer.setVvalue(p.getY()/mapViewInnerContainer.getPrefHeight());

                }
            }
        });

    }

}