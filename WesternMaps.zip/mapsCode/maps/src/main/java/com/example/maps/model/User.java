package com.example.maps.model;

import org.json.JSONException;
import org.json.JSONObject;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.util.List;
import java.util.ArrayList;

public class User {

    private String firstName , lastName;
    private String email;
    private String password;

    private List<Point> points ;

    public static User currentLoggedUser;


    public User(String firstName , String lastName , String email , String password) {

        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.password = password;
        this.points = new ArrayList<>();
    }

    public String getFirstName() {
        return this.firstName;
    }
    public String getLastName() {
        return this.lastName;
    }
    public String getEmail() {
        return this.email;
    }
    public String getPassword() {
        return this.password;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    public void setEmail(String email) {
        this.email = email;
    }


    public List<Point> getPoints() {
        return this.points;
    }
    public void setPoints(List<Point> points) {
        this.points = points;
    }


    /**
     *
     * create a hash-message of the given input using sha-256 algorithm
     *
     * @param input given input
     * @return sha-256 hash of the given input or null if any error was occurred
     */
    public static final String getDigest(String input) {

        try {
            String output = new BigInteger(1 , MessageDigest.getInstance("sha-256").digest(input.getBytes())).toString(16);

            while(output.length()<64)
                output = String.valueOf(0).concat(output);
            return output;
        }
        catch(Exception ex) {

        }

        return null;
    }



}
