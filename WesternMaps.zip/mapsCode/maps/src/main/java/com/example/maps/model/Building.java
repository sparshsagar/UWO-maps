package com.example.maps.model;

import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;


import javafx.scene.control.Button;

public class Building {

    public static final Map<Button , Building> buttonBuildingMap = new HashMap<>();

    private String name;
    private List<Floor> floors;

    public Building(String name , Floor... floors) {

        this.name = name;
        this.floors = Arrays.asList(floors);
    }
    public Building(String name , List<Floor> floors) {
        this.name = name;
        this.floors = floors;
    }

    public void setName(String name) {
        this.name = name;
    }


    public String getName() {
        return this.name;
    }
    public List<Floor> getFloors() {
        return this.floors;
    }
}
