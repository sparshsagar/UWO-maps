package com.example.maps.controller;


import com.example.maps.model.Developer;
import com.example.maps.model.Point;
import com.example.maps.model.PointTypes;
import com.example.maps.model.User;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Button;
import javafx.scene.layout.Pane;

import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import java.io.IOException;
import java.io.FileReader;
import java.io.BufferedReader;

import javafx.stage.Stage;
import org.json.JSONObject;
import org.json.JSONArray;


public class LoginController implements Initializable {

    @FXML
    private PasswordField passwordInput;

    @FXML
    private TextField emailInput;

    @FXML
    private Button signupButton , loginButton;

    @FXML
    private Pane rootContainer;

    public static List<Point> developersPoints = new ArrayList<>();


    public static int jsonObjectIndex;

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        File file = new File("./data");

        if(!file.exists() || !file.isDirectory()) {
            file.mkdir();
        }

        file = new File("./data/users.json");
        if(!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {

            }
        }

        file = new File("./data/developers.json");
        if(!file.exists()) {
            try {
                file.createNewFile();
            }
            catch(IOException e) {

            }
        }

    }


    @FXML
    private void signupMouseEnter() {

        this.signupButton.setStyle("-fx-background-color: #A5D7E8; -fx-background-radius: 5;");
    }
    @FXML
    private void signupMouseExit() {
        this.signupButton.setStyle("-fx-background-color: #19376D; -fx-background-radius: 5;");
    }

    @FXML
    private void loginMouseEnter() {
        this.loginButton.setStyle("-fx-background-color: #A5D7E8; -fx-background-radius: 5;");
    }
    @FXML
    private void loginMouseExit() {
        this.loginButton.setStyle("-fx-background-color: #19376D; -fx-background-radius: 5;");
    }

    /**
     *
     * this is an even handler for login button, when the button clicked it collect the text written in both email TextField and password's PasswordField then it checks if there is user with the given credentials, if yes the user will be taken to the app window otherwise an alert stage will appear
     *
     * @throws Exception
     */
    @FXML
    private void login() throws Exception {

        String email = emailInput.getText();
        String password = passwordInput.getText();
        String hashedPassword = User.getDigest(password);

        User loggedUser = null;

        try {
            BufferedReader reader = new BufferedReader(new FileReader("./data/developers.json"));
            String line , content="";

            while((line=reader.readLine())!=null) {
                content = content.concat(line);
            }
            //check in developer json file first !

            JSONArray usersJSONArray = new JSONArray(content.isEmpty() ? "[]" : content);
            JSONObject authUser = getAuthUser(usersJSONArray , email , hashedPassword);
            if(authUser==null) {
                //check in users json file !
                reader = new BufferedReader(new FileReader("./data/users.json"));

                content = "";

                while((line=reader.readLine())!=null)
                    content = content.concat(line);

                usersJSONArray = new JSONArray(content.isEmpty() ? "[]" : content);
                authUser = getAuthUser(usersJSONArray , email , hashedPassword);
                if(authUser==null) {

                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Non authenticated !");
                    alert.setHeaderText("Could not Login with these credentials !");
                    alert.setContentText("Signup for new Account or Contact app developer if something went wrong !");
                    alert.showAndWait();

                    emailInput.clear();
                    passwordInput.clear();
                    return;
                }
                //the user exists & it's not a developer
                loggedUser = getUser(authUser , User.class);
            }
            else {
                //the user exists & it's a developer
                loggedUser = getUser(authUser , Developer.class);
            }

            User.currentLoggedUser = loggedUser;
            loadDevelopersPoints();
            Parent appView = FXMLLoader.load(this.getClass().getResource("/com/example/maps/mainView.fxml"));
            this.rootContainer.getScene().setRoot(appView);
            ((Stage)appView.getScene().getWindow()).setMinHeight(850);
            ((Stage)appView.getScene().getWindow()).setMinWidth(1150);
            ((Stage)appView.getScene().getWindow()).centerOnScreen();
            ((Stage)appView.getScene().getWindow()).setResizable(true);



        }
        catch(Exception e) {
            e.printStackTrace();
        }

    }

    /**
     *
     * this is an event handler for signup button, when user click on signup window should load signup view
     *
     * @throws Exception
     */
    @FXML
    private void signup() throws Exception {

        Parent signupParent = FXMLLoader.load(this.getClass().getResource("/com/example/maps/signup.fxml"));
        this.rootContainer.getScene().setRoot(signupParent);
    }

    /**
     * search in the json array that contains all users and return json object of the authenticated user, or null if it could not be found
     *
     * @param jsonArray json array loaded from the developers.json | users.json file
     * @param email email given by user
     * @param hashedPassword sha-256 hash of the password given by user
     * @return JSONObject of the authenticated user, or null if no user found with the given credentials
     * @throws Exception
     */
    public JSONObject getAuthUser(JSONArray jsonArray , String email , String hashedPassword) throws Exception {


        for(int i=0; i<jsonArray.length(); i++) {

            JSONObject current = jsonArray.getJSONObject(i);
            String currentEmail = current.getString("email");
            String currentHashedPassword = current.getString("password");

            if(email.equals(currentEmail) && hashedPassword.equalsIgnoreCase(currentHashedPassword)) {
                jsonObjectIndex = i;
                return current;
            }
        }

        return null;
    }

    /**
     * this function used to created instance of user using json object that have fields of user object as keys
     *
     * @param userJSONObject user json object
     * @param userType Class type , User for normal user , Developer if the user was an admin/developer
     * @return user instance that was created using the given user json object
     * @throws Exception
     */
    public User getUser(JSONObject userJSONObject , Class userType) throws Exception {

        User authUser ;

        String firstName = userJSONObject.getString("firstName");
        String lastName = userJSONObject.getString("lastName");
        String email = userJSONObject.getString("email");
        String password = userJSONObject.getString("password");

        if(userType.equals(User.class)) {
            authUser = new User(firstName , lastName, email , password);
        }
        else {
            authUser = new Developer(firstName , lastName, email , password);
        }

        JSONArray pointsJSONArray = userJSONObject.getJSONArray("points");
        List<Point> points = getPoints(pointsJSONArray);

        authUser.setPoints(points);

        return authUser;
    }

    private List<Point> getPoints(JSONArray pointsJSONArray) throws Exception {

        List<Point> result = new ArrayList<>();

        for(int i=0; i<pointsJSONArray.length(); i++) {

            result.add(getPoint(pointsJSONArray.getJSONObject(i)));
        }

        return result;
    }

    /**
     *
     * instantiate a Point object using json object that has the same fields of Point class as keys
     *
     * @param pointJSONObject given json object with keys same as Point class fields
     * @return the created point
     * @throws Exception
     */
    private Point getPoint(JSONObject pointJSONObject) throws Exception{

        Point p ;

        String buildingName = pointJSONObject.getString("buildingName");
        String floorName = pointJSONObject.getString("floorName");
        String roomNumber = pointJSONObject.getString("roomNumber");
        String name = pointJSONObject.getString("name");
        String type = pointJSONObject.getString("type");
        String additionalInformation = pointJSONObject.getString("additionalInformation");
        double x = pointJSONObject.getDouble("x");
        double y = pointJSONObject.getDouble("y");
        String hours = pointJSONObject.getString("hours");
        String roomCapacity = pointJSONObject.getString("roomCapacity");

        p = new Point(buildingName , floorName , roomNumber , name , type , x , y , additionalInformation);
        p.setHours(hours);
        p.setRoomCapacity(roomCapacity);

        return p;
    }

    /**
     *
     * call the function getUser() to create a developer object
     *
     * @param obj json object that has the same keys as User fields
     * @return developer object
     * @throws Exception
     */
    private Developer getDeveloper(JSONObject obj) throws Exception {

        return (Developer)getUser(obj , Developer.class);
    }

    /**
     *
     * call this function to load points that were created by developer, i.e these points should be appeared to all users and users cannot delete them or replace them to another location
     *
     * @throws Exception
     */
    private void loadDevelopersPoints() throws Exception {

        BufferedReader reader = new BufferedReader(new FileReader("./data/developers.json"));

        String line , content="";

        while((line=reader.readLine())!=null) {
            content = content.concat(line);
        }

        JSONArray arr = new JSONArray(content.isEmpty() ? "[]" : content);

        for(int i=0; i<arr.length(); i++) {

            JSONObject currentObject = arr.getJSONObject(0);
            Developer currentDeveloper = getDeveloper(currentObject);

            developersPoints.addAll(currentDeveloper.getPoints());
        }
    }
}