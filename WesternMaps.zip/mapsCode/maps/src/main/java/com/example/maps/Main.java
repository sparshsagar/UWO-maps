package com.example.maps;

import com.example.maps.controller.Controller;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import javafx.stage.Window;

import java.io.IOException;
import java.io.*;


public class Main extends Application {

    public static Window applicationWindow;
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("/com/example/maps/login.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 600, 400);
        stage.setTitle("Western Maps");
        stage.setScene(scene);
        stage.show();
        stage.sizeToScene();
        stage.setResizable(false);
        applicationWindow = stage;

        stage.getIcons().add(new Image(this.getClass().getResourceAsStream("/com/example/maps/images/logo.jpg")));
    }

    public static void main(String[] args) throws Exception {
        launch();
    }

    @Override
    public void stop() {

        try {
            Controller.timer.cancel();
        }
        catch(Exception e) {

        }
    }
}