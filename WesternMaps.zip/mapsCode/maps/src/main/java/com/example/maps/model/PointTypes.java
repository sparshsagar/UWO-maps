package com.example.maps.model;



public enum PointTypes {

    Classroom,
    Lab,
    Recreation,
    Collaboration,
    Accessibility,
    Restaurant,
    Washroom,
    Library,
    Navigation,
    Custom
}