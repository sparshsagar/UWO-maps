module com.example.maps {
    requires javafx.controls;
    requires javafx.fxml;
    requires org.json;
    requires java.net.http;


    opens com.example.maps to javafx.fxml;
    opens com.example.maps.controller to javafx.fxml , javafx.controls;
    opens com.example.maps.model to org.json , java.net.http;
    exports com.example.maps;

}