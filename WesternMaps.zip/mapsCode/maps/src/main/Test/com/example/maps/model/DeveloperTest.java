package com.example.maps.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DeveloperTest {

    @Test
    void testInstance() {

        User user = new User("first name","last name" , "name@example.com" , "b7aa19d33add937b884a01b4567a7e2038d46f179ec3d317a66c2c5f927cd06c");
        assertFalse((user instanceof Developer));
        User developer = new Developer("first name" , "last name" , "name@example.com" , "b7aa19d33add937b884a01b4567a7e2038d46f179ec3d317a66c2c5f927cd06c");
        assertTrue(developer instanceof Developer);

    }

}