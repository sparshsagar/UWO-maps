package com.example.maps.model;

import com.example.maps.model.*;
import java.util.*;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class UserTest {

    @Test
    void getPoints() {

        List<Point> list = new User("first" , "last" , "name@example.com" , "b7aa19d33add937b884a01b4567a7e2038d46f179ec3d317a66c2c5f927cd06c").getPoints();

        assertNotNull(list);
    }

    @Test
    void setPoints() {

        User user = new User("first" , "last" , "name@example.com" , "b7aa19d33add937b884a01b4567a7e2038d46f179ec3d317a66c2c5f927cd06c");

        user.setPoints(null);

        assertNull(user.getPoints());
    }

    @Test
    void getDigest() {

        String password = "passw0rd!";
        String hash = "b7aa19d33add937b884a01b4567a7e2038d46f179ec3d317a66c2c5f927cd06c";

        assertEquals(User.getDigest(password) , hash);
    }
}