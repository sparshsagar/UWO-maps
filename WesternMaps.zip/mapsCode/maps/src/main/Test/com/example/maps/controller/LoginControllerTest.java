package com.example.maps.controller;

import com.example.maps.model.User;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class LoginControllerTest {

    @Test
    void getUser() throws Exception {

        JSONObject user = new LoginController().getAuthUser(new JSONArray("[]") , "username" , "password");

        assertNull(user);
    }

}