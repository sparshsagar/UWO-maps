Western Maps is a software that helps Western University students and staff to navigate the buildings of campus. 

Currently you can view all the floors of the Health Science Building, Alumni Hall, and Middlesex College.

Once you are in the software you will be able to browse the floors to see variuos points of interests such as classrooms, labs, bathrooms etc. Double clicking on a point will display some information about it.

As a user you can also create your own points of intersts if there is a location that does not currently have a point.



Required Libraries:

-Using the intellij IDE is recommended but not required.
-JDK 18 or later
-Maven which includes org.simple.json, javaFX, and JUnit

Guide to build and run the code:

-Clone the repository to your system
-Open the project in the IDE
-Navigate to the main class with this path: maps/src/main/java/com/example/maps/main
-Once you are in the main class, in intellij there is a button on the top that looks like a hammer.
-Press that button and Western Maps should start being built
-Once it is completed, simply run the main class and Western Maps will open

How to use Western Maps:

-When Western Maps first launches you must signup with an email and password then login.
-Once you login you will be able to navigate all the buildings and floors using the buttons on the left side of the application.
-You can browse the currently displayed floor by scrolling.
-To view information about a point simply double click on it.
-You can also add a point to favorites after double clicking on it.
-You can also navigate to a specific point by clicking on the one you want from the list of points on the right side of the application.
-If you want to filter to search for only a specific type of a point, you can use the filter function on the bottom right of the application.
-To create your own point, click on the "Create POI", then input the information you want for the point. After creating it a point will display on the map which you can drag to your desired location.


Developer Mode:

To access developer mode you will have to use this login information:

email: john@gmail.com
password: password123

In developer mode you can move/delete the built in pointys of interest


Notes for TA:

We adde the weather API as a bonus extra feature over the existing multi user system extra feature.